'use strict'

import React from 'react'

import 'normalize.css'
import 'milligram'

const App = () => (
  <div style={{ display: 'flex', justifyContent: 'space-around', padding: 30 }}>
    <div>
      <h1>Boilerplate Pre-ReactFlix</h1>
    </div>

  </div>
)

export default App
