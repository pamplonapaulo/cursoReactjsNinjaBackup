'use strict'

import { combineReducers } from 'redux'

export default combineReducers({})
