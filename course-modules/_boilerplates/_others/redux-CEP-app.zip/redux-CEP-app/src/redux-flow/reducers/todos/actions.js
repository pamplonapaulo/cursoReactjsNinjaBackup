'use strict'

export const ADD_TODO = 'todos:ADD_TODO'
export const TOGGLE_TODO = 'todos:TOGGLE_TODO'
