'use strict'

export const SET_VISIBILITY_FILTER = 'visibilityFilter:SET_VISIBILITY_FILTER'

export const SHOW_ALL = 'visibilityFilter:SHOW_ALL'
export const SHOW_COMPLETED = 'visibilityFilter:SHOW_COMPLETED'
export const SHOW_ACTIVE = 'visibilityFilter:SHOW_ACTIVE'
