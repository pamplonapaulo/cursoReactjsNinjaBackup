'use strict'

export const FETCHING = 'address:FETCHING'
export const SUCCESS = 'address:UPDATE_ADDRESS'
