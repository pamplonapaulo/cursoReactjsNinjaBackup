'use strict'

module.exports = require('../webpack/storybook.config')
