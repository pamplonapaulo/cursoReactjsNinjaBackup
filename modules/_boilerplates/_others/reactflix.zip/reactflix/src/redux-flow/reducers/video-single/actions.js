'use strict'

export const SELECT_VIDEO_SINGLE = 'videoSingle:SELECT_VIDEO_SINGLE'
