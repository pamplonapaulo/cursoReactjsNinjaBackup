'use strict'

export const ADD_VIDEO = 'videos:ADD_VIDEO'
