'use strict'

export const headerHeight = '60px'
export const footerHeight = '30px'
