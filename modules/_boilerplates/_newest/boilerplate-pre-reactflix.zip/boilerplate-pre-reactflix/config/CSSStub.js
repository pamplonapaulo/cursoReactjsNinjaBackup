'use strict'

module.exports = {}
