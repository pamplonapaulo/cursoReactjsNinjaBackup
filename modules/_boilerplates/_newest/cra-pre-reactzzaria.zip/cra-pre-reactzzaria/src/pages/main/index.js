export { default as MainPage } from './main'
