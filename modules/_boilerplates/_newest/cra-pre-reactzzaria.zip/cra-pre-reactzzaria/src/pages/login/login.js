import React from 'react'

const Login = () => (
  <h1>Login</h1>
)

export default Login
